#!/bin/bash


/opt/conda/bin/python ./polly_script.py

echo "python executed"

cellxgene launch --host 0.0.0.0 --port 5005 --disable-annotations --verbose file.h5ad
